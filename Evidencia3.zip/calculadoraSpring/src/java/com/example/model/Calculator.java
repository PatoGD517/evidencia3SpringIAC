/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.model;

/**
 *
 * @author sanfa
 */
public class Calculator {
    // Atributos
    private double cadera;    // metros
    private double estatura;

    public Calculator(double cadera, double estatura) {
        this.cadera = cadera;
        this.estatura = estatura;

    }

    public double getResult(double cadera,double estatura) {
        return (cadera / Math.pow(estatura, 1.5)) - 18;
    }
}
